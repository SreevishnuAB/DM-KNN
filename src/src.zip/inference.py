import pickle
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

def perform_inference(annual_income, spending_score):
    data = pd.read_csv("C:\\Users\\i518703\\OneDrive - SAP SE\\Documents\\BITS\\Sem 3\\DM\\Assignment\\mall_data_labelled.csv")
    print(data.head())
    model = pickle.load(open("spend_model_knn.pkl", "rb"))
    new_point = np.array([[annual_income, spending_score]])
    # new_point_scaled  = MinMaxScaler().fit_transform(new_point)
    print(new_point)
    # print(new_point_scaled)
    print(f"Predicted class: {model.predict(new_point)}")
    nearest_neighbors = model.kneighbors(new_point, n_neighbors=3)
    y = data[nearest_neighbors[1][0]]
    print(y)
    print("Nearest neighbors")
    for i in range(len(nearest_neighbors[1][0])):
        print(data.iloc[nearest_neighbors[1][0][i]])
        print(f"Distance: {nearest_neighbors[0][0][i]}\n")

if __name__ == "__main__":
    annual_income = float(input("Annual income: "))
    spending_score = float(input("Spending score: "))
    perform_inference(annual_income, spending_score)